﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practic_5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Task> personalTasks = new ObservableCollection<Task>();
        public ObservableCollection<Task> workTasks = new ObservableCollection<Task>();
        public ObservableCollection<Task> additionalTasks = new ObservableCollection<Task>();

         
        public MainWindow()
        {
            InitializeComponent();
            PersonalTasksListBox.ItemsSource = personalTasks;
            WorkTasksListBox.ItemsSource = workTasks;
            AdditionalTasksListBox.ItemsSource = additionalTasks;



        }
        private void UpdatepersonalList()
        {
            if (PersonalTasksListBox.SelectedIndex == -1) return;
            PersonalTasksListBox.Items.Remove(PersonalTasksListBox.SelectedIndex);
        }

        private void UpdateworkList()
        {
            if (WorkTasksListBox.SelectedIndex == -1) return;
            WorkTasksListBox.Items.Remove(WorkTasksListBox.SelectedIndex);
        }

        private void UpdateadditionalTasks()
        {
            if (AdditionalTasksListBox.SelectedIndex == -1) return;
            AdditionalTasksListBox.Items.Remove(AdditionalTasksListBox.SelectedIndex);
        }
        public void AddTask(Task task)
        {
            switch (task.Category)
            {
                case "Личные":
                    personalTasks.Add(task);
                    PersonalTasksListBox.ItemsSource = null;
                    PersonalTasksListBox.ItemsSource = personalTasks;
                    break;
                case "Рабочие":
                    workTasks.Add(task);
                    WorkTasksListBox.ItemsSource = null;
                    WorkTasksListBox.ItemsSource = workTasks;

                    break;
                case "Дополнительные":
                    additionalTasks.Add(task);
                    AdditionalTasksListBox.ItemsSource = null;
                    AdditionalTasksListBox.ItemsSource = additionalTasks;
                    break;
            }
        }
        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {

            AddTaskWindow addTaskWindow = new AddTaskWindow(this);
            addTaskWindow.ShowDialog();
        }

        private void RemoveTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (PersonalTasksListBox.SelectedItem is Task selectedPersonalTask)
            {
                personalTasks.Remove(selectedPersonalTask);
                UpdatepersonalList();



            }
            if (WorkTasksListBox.SelectedItem is Task selectedWorkTask)
            {
                workTasks.Remove(selectedWorkTask);
                UpdateworkList();
               

            }
            if (AdditionalTasksListBox.SelectedItem is Task selectedAdditionalTask)
            {
                additionalTasks.Remove(selectedAdditionalTask);
                UpdateadditionalTasks();

            }
        }

        private void AdditionalPriorityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectesPriority = (AdditionaltasksComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            var filteredTasks = additionalTasks.Where(task => task.Priority == selectesPriority).ToList();
            AdditionalTasksListBox.ItemsSource = null;
            AdditionalTasksListBox.ItemsSource = filteredTasks;
        }

        private void WorklPriorityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectesPriority = (WorktasksComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            var filteredTasks = workTasks.Where(task => task.Priority == selectesPriority).ToList();
            WorkTasksListBox.ItemsSource = null;
            WorkTasksListBox.ItemsSource = filteredTasks;
        }

        private void PersonalPriorityComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selectesPriority = (PersonalPriorityComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            var filteredTasks = personalTasks.Where(task => task.Priority == selectesPriority).ToList();
            PersonalTasksListBox.ItemsSource = null;
            PersonalTasksListBox.ItemsSource = filteredTasks;
        }

        private void check_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            if (cb.IsChecked == true)
            {
                PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Red);
            }
            else
            {
                PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Blue);
            }
          
          
        }

        private void check_Unchecked(object sender, RoutedEventArgs e)
        {

                PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Red);
        }

        private void check_Indeterminate(object sender, RoutedEventArgs e)
        {
              PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Blue);
        }

        private void check_Checked_1(object sender, RoutedEventArgs e)
        {

        }

        private void check_Click(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            if (cb.IsChecked == true)
            {
                PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                PersonalTasksListBox.Foreground = new SolidColorBrush(Colors.Black);
            }

        }

        private void check1_Click(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            if (cb.IsChecked == true)
            {
                AdditionalTasksListBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                AdditionalTasksListBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }

        private void check2_Click(object sender, RoutedEventArgs e)
        {
            CheckBox cb = sender as CheckBox;
            if (cb.IsChecked == true)
            {
                WorkTasksListBox.Foreground = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                WorkTasksListBox.Foreground = new SolidColorBrush(Colors.Black);
            }
        }
    }
}