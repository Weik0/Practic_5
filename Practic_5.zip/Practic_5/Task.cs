﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practic_5
{
    public class Task
    {
        public string Title { get; set; }
        public string Category { get; set; }
        public string Priority { get; set; }
        public bool IsCompleted { get; set; }
        public Task(string title, string category, string priority, bool Completed = false)
        {
            Title = title;
            Category = category;
            Priority = priority;
            IsCompleted = Completed;
             
            
        }
    }
}
