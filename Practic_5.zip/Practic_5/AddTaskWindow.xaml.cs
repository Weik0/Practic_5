﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Practic_5
{
    /// <summary>
    /// Логика взаимодействия для AddTaskWindow.xaml
    /// </summary>
    public partial class AddTaskWindow : Window
    {
        private MainWindow _mainWindow;

        public AddTaskWindow(MainWindow mainWindow)
        {
            InitializeComponent();
            this._mainWindow = mainWindow;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {

            string title = TaskTitleTextBox.Text;
            string category = (TaskCategoryComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            string priority = (NewTaskPriorityComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (!string.IsNullOrWhiteSpace(title) && !string.IsNullOrWhiteSpace(category) && !string.IsNullOrWhiteSpace(priority))
            {
                Task newTask = new Task(title, category, priority, false);
                _mainWindow.AddTask(newTask);
                this.DialogResult = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Пожалуйста, заполните все поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
     
    
}
